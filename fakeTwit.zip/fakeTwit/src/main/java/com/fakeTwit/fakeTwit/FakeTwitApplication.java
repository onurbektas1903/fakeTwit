package com.fakeTwit.fakeTwit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FakeTwitApplication {

	public static void main(String[] args) {
		SpringApplication.run(FakeTwitApplication.class, args);
	}
}
